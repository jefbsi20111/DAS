INSERT INTO DAS_core_telefone (numero, tipo) VALUES ('9969-9999', 'CE');
